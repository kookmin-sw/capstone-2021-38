<template>
  <div class="app-container">
    <el-card :body-style="{ paddingBottom: '2px' }" class="radius-8 mb-10">
      <el-form ref="form" :model="searchModel" inline>
        <el-form-item prop="com" label="寄件公司">
          <el-select
            v-model="searchModel.com"
            placeholder="请选择快递公司"
            filterable
          >
            <el-option v-for="(option, i) in allOptions.company_info" :key="i" v-bind="option" />
          </el-select>
        </el-form-item>
        <el-form-item prop="recManName" label="收件人名称">
          <el-input v-model="searchModel.recManName" placeholder="收件人名称" />
        </el-form-item>
        <el-form-item prop="recManMobile" label="收件人手机号">
          <el-input v-model="searchModel.recManMobile" placeholder="收件人手机号" />
        </el-form-item>
        <el-form-item prop="recManPrintAddr" label="收件人地址">
          <el-input v-model="searchModel.recManPrintAddr" placeholder="收件人地址" />
        </el-form-item>
        <!-- <el-form-item prop="create_time" label="下单时间">
        <el-date-picker
          v-model="searchModel.recManPrintAddr"
          type="daterange"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          range-separator="至"
        />
      </el-form-item> -->
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="handleSearch">查询</el-button>
          <el-button type="default" icon="el-icon-" @click="handleReset('form')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card :body-style="{ padding: '0' }" class="radius-8 mb-5">
      <el-button size="medium" type="primary" icon="el-icon-s-promotion" @click="handleAction('insert')">寄件</el-button>
    </el-card>

    <el-card :body-style="{ padding: '0' }" class="radius-8 mb-5">
      <el-table :data="tableData" stripe highlight-current-row header-row-class-name="table-header">
        <!-- <el-table-column prop="user" label="用户名" /> -->
        <el-table-column prop="com" label="快递公司" :formatter="formatCompany" />
        <el-table-column prop="num" label="运单号" />
        <el-table-column prop="courierName" label="快递员姓名" />
        <el-table-column prop="courierMobile" label="快递员电话" />
        <el-table-column prop="recManName" label="收件人姓名" min-width="100px" />
        <el-table-column prop="recManMobile" label="收件人手机号" min-width="110px" />
        <el-table-column prop="recManPrintAddr" label="收件人地址" min-width="140px" />
        <el-table-column prop="sendManName" label="寄件人姓名" min-width="100px" />
        <el-table-column prop="sendManMobile" label="寄件人手机号" min-width="110px" />
        <el-table-column prop="sendManPrintAddr" label="寄件人地址" min-width="140px" />
        <el-table-column prop="cargo" label="物品名称" />
        <el-table-column prop="weight" label="物品重量(kg)" min-width="110px" />
        <el-table-column prop="freight" label="运费" />
        <el-table-column prop="serviceType" label="服务类型" />
        <el-table-column prop="remark" label="备注" />
        <el-table-column prop="cancelMsg" label="取消原因" />
        <el-table-column prop="create_time" label="创建时间" width="140px" sortable />
        <el-table-column prop="status" label="寄件信息状态" min-width="110px" class-name="status-col" fixed="right">
          <template slot-scope="scope">
            <el-tag
              :type="scope.row.status | formatStatusType"
              disable-transitions
            >{{ formatValue('send_record_status', scope.row.status) }}</el-tag>
          </template>
        </el-table-column>
        <!-- <el-table-column label="寄件详情" width="150px" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="text"
              size="mini"
              :disabled="scope.row.status == '02'"
              @click="handleAction('detail', scope.row, scope.$index)"
            >
              查看详情
            </el-button>
          </template>
        </el-table-column> -->
        <el-table-column label="操作" width="150px" fixed="right">
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              :disabled="scope.row.status !== '03'"
              @click="handleAction('retry', scope.row, scope.$index)"
            >
              重试
            </el-button>
            <el-button
              type="danger"
              size="mini"
              :disabled="scope.row.status !== '02'"
              @click="handleAction('cancel', scope.row, scope.$index)"
            >
              取消
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card v-show="total > currentPage * pageSize" :body-style="{ padding: '6px 0' }" class="radius-8">
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :hide-on-single-page="true"
        :total="total"
        :current-page="currentPage"
        :page-size="pageSize"
        class="text-center"
        @current-change="(val) => handlePageSize({ currentPage: val, pageSize: pageSize })"
        @size-change="(val) => handlePageSize({ currentPage: currentPage, pageSize: val })"
      />
    </el-card>

    <el-tooltip placement="top" content="返回顶部">
      <back-to-top :custom-style="myBackToTopStyle" :visibility-height="300" :back-position="50" transition-name="fade" />
    </el-tooltip>

    <el-dialog width="650px" title="寄件" :visible.sync="showDelivery">
      <el-form :model="insertModel" label-width="110px" label-suffix=":">
        <el-row>
          <el-col :span="12">
            <el-form-item prop="sendManName" label="寄件人姓名">
              <el-input v-model="insertModel.sendManName" placeholder="寄件人姓名" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="sendManMobile" label="寄件人手机号">
              <el-input v-model="insertModel.sendManMobile" placeholder="寄件人手机号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item prop="sendManPrintAddr" label="寄件人地址">
          <el-input v-model="insertModel.sendManPrintAddr" type="textarea" :rows="2" placeholder="寄件人地址" @blur="() => getShipperCompany(insertModel.sendManPrintAddr)" />
        </el-form-item>
        <el-row>
          <el-col :span="12">
            <el-form-item prop="com" label="快递公司">
              <el-select
                v-model="insertModel.com"
                placeholder="请选择快递公司"
                filterable
                style="width: 100%"
                @change="getServiceType"
              >
                <el-option v-for="(option, i) in shipperCompany" :key="i" v-bind="option" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="serviceType" label="业务服务类型">
              <el-select v-model="insertModel.serviceType" style="width: 100%">
                <el-option v-for="(option, i) in serviceType" :key="i" v-bind="option" />
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="12">
            <el-form-item prop="recManName" label="收件人姓名">
              <el-input v-model="insertModel.recManName" placeholder="收件人姓名" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item prop="recManMobile" label="收件人手机号">
              <el-input v-model="insertModel.recManMobile" placeholder="收件人手机号" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item prop="recManPrintAddr" label="收件人地址">
          <el-input v-model="insertModel.recManPrintAddr" type="textarea" :rows="2" placeholder="收件人地址" />
        </el-form-item>

        <el-form-item prop="cargo" label="物品名称">
          <el-input v-model="insertModel.cargo" placeholder="物品名称" />
        </el-form-item>
        <el-form-item prop="weight" label="物品重量">
          <el-col :span="12">
            <el-input-number v-model="insertModel.weight" :min="0" style="width: 98%" />
          </el-col>
          <el-col :span="12">
            <strong> Kg</strong>
          </el-col>
        </el-form-item>
        <el-form-item prop="remark" label="备注">
          <el-input v-model="insertModel.remark" placeholder="备注" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showDelivery = false">取 消</el-button>
        <el-button type="primary" @click="handleConfirm('insert', insertModel)">确 定</el-button>
      </template>
    </el-dialog>

    <el-dialog width="650px" title="寄件详情" :visible.sync="showDetail">
      <el-card class="radius-8">
        <template #header>
          <el-row :gutter="20" type="flex" align="middle" class="flex-wrap">
            <el-col :xs="24" :sm="16" :md="20" class="line-height">
              <div>运单号：{{ detailModel.nu }}</div>
              <div>
                快递公司：{{ formatValue('company_info', detailModel.com) }}
                <el-tag :type="detailModel.state | formStateType">{{ expressState }}</el-tag>
              </div>
            </el-col>
            <el-col :xs="24" :sm="8" :md="4" class="text-right">
              <el-button icon="el-icon-position" @click="handleMapTrack">物流轨迹</el-button>
            </el-col>
          </el-row>
        </template>
        <el-timeline v-if="Array.isArray(detailModel.data)">
          <el-timeline-item
            v-for="(item, index) of detailModel.data"
            :key="index"
            :timestamp="item.time"
            :type="item | formatStatusType(expressState)"
            size="large"
            placement="top"
          >
            <el-card :body-style="{ padding: '0 20px' }" class="radius-4">
              <h4>{{ item.status }}</h4>
              <p>{{ item.context }}</p>
            </el-card>
          </el-timeline-item>
        </el-timeline>
      </el-card>
      <template #footer>
        <el-button @click="showDelivery = false">取 消</el-button>
        <el-button type="primary" @click="handleConfirm('detail')">确 定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import express from '@/utils/express'
import BackToTop from '@/components/BackToTop'
// eslint-disable-next-line no-unused-vars
import { getShipperCompany, createOrder, selectOrder, cancelOrder } from '@/api/express-send'
export default {
  name: 'ExpressDelivery',
  components: { BackToTop },
  filters: {
    formStateType(state) {
      return express.state[state] || state
    },
    formatStatusType(status) {
      return express.status[status] || ''
    }
  },
  data() {
    this.allData = []
    return {
      showDelivery: false,
      showDetail: false,
      myBackToTopStyle: {
        'z-index': 3,
        right: '50px',
        bottom: '20px',
        width: '40px',
        height: '40px',
        'border-radius': '4px',
        'line-height': '45px',
        background: '#e7eaf1'
      },
      shipperCompany: [], // 可以寄件的快递公司
      serviceType: [ // 业务服务类型
        { label: '标准快递', value: '标准快递' }
      ],
      searchModel: { com: '', recManName: '', recManMobile: '', recManPrintAddr: '' },
      insertModel: { com: '', serviceType: '', weight: 0 },
      detailModel: {},
      expressState: '',
      total: this.allData.length,
      currentPage: 1,
      pageSize: 10,
      tableData: [],
      insertRules: {
        com: [
          { required: true, message: '请选择快递公司' }
        ],
        serviceType: [
          { required: true, message: '请选择业务服务类型' }
        ],
        recManName: [
          { required: true, message: '请填写收件人姓名' }
        ],
        recManMobile: [
          { required: true, message: '请填写收件人手机号' }
        ],
        recManPrintAddr: [
          { required: true, message: '请填写收件人地址' }
        ],
        sendManName: [
          { required: true, message: '请填写寄件人姓名' }
        ],
        sendManMobile: [
          { required: true, message: '请填写寄件人手机号' }
        ],
        sendManPrintAddr: [
          { required: true, message: '请填写寄件人地址' }
        ],
        cargo: [
          { required: true, message: '请填写物品名称' }
        ],
        weight: [
          { required: true, message: '请填写物品重量' }
        ]
      }
    }
  },
  computed: {
    ...mapGetters(['allOptions'])
  },
  watch: {
    'allOptions.addr': {
      handler: 'getShipperCompany',
      immediate: true
    }
  },
  created() {
    // 测试使用
    // const { currentPage, pageSize } = this
    // this.handlePageSize({ currentPage, pageSize })
  },
  methods: {
    handleSearch() {
      selectOrder(this.searchModel).then(result => {
        this.allData = result.response_data || []
        this.total = this.allData.length
        const { currentPage, pageSize } = this
        this.handlePageSize({ currentPage, pageSize })
      })
    },
    handleReset(formName) {
      this.$refs[formName].resetFields()
    },
    handlePageSize({ currentPage, pageSize }) {
      const startIndex = (currentPage - 1) * pageSize
      const endIndex = currentPage * pageSize
      this.currentPage = currentPage
      this.pageSize = pageSize
      this.tableData = this.allData.slice(startIndex, endIndex)
    },
    handleAction(action, row = {}, index) {
      switch (action) {
        case 'insert':
          this.showDelivery = true
          break
        case 'retry':
          this.handleConfirm('insert', { id: row.id })
          break
        case 'detail':
          this.detailModel = row
          this.showDetail = true
          break
        case 'cancel':
          this.$prompt('请填写取消原因', '取消订单', {
            closeOnClickModal: false,
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            inputType: 'textarea',
            inputValidator: (value) => {
              return value && value.length > 0 ? true : '请填写取消原因'
            }
          }).then(({ value }) => {
            const model = {
              id: row.id,
              cancelMsg: value
            }
            this.handleConfirm(action, model)
          }).catch(() => {
            this.$message.info('您关闭了取消申请')
          })
          break
      }
    },
    handleConfirm(action, model) {
      switch (action) {
        case 'insert':
          createOrder(model).then(result => {
            this.$message.success('下单成功')
            this.showDelivery = false
            this.handleSearch()
          })
          break
        case 'cancel':
          cancelOrder(model).then(result => {
            this.$message.success('取消成功')
            this.handleSearch()
          })
          break
      }
    },
    getServiceType(com) {
      this.serviceType = this.shipperCompany.reduce((t, v) => v.value === com ? v.serviceType : t, [])
      if (this.serviceType.length === 1) {
        this.insertModel.serviceType = this.serviceType[0].value
      }
    },
    getShipperCompany(sendManPrintAddr) {
      // 寄件人信息自动填充
      const { name, phone, addr } = this.allOptions
      const sendAddr = sendManPrintAddr || addr
      const autocomplete = {
        sendManName: name,
        sendManMobile: phone,
        sendManPrintAddr: sendAddr
      }
      this.insertModel = { ...this.insertModel, ...autocomplete }
      // 获取寄件公司
      getShipperCompany({ sendAddr: sendAddr }).then(result => {
        const data = result.response_data || { mktInfo: [] }
        const getCompanyInfo = (com) => this.allOptions.company_info.filter(v => v.value === com)
        const getServiceType = (type) => {
          if (!type) return [{ label: '标准快递', value: '标准快递' }]
          return type.map(v => {
            return { label: v, value: v }
          })
        }
        this.shipperCompany = data.mktInfo.reduce((t, { com, serviceType }) => {
          const info = getCompanyInfo(com)
          const type = getServiceType(serviceType)
          return info.length === 1 ? [...t, { ...info[0], serviceType: type }] : t
        }, [])
      })
    },
    // todo 寄件详情信息
    handleMapTrack() {
      console.log(this.detailModel)
    },
    formatCompany(row, column, cellValue, index) {
      return this.formatValue('company_info', cellValue)
    },
    formatValue(key, value) {
      return this.allOptions[key].reduce((t, v) => v.value === value ? v.label : t, value)
    }
  }
}

</script>
<style lang="scss" scoped>
.wrapper { display: block; }
</style>
