<template>
  <div class="app-container express-detail">
    <el-card :body-style="{ padding: 0 }" class="radius-8">
      <template #header>
        <el-row type="flex" align="middle" class="flex-wrap">
          <el-col :xs="24" :sm="12">
            快递信息
          </el-col>
          <el-col :xs="24" :sm="12" class="text-right">
            <el-button @click="goBack">返回上一页</el-button>
          </el-col>
        </el-row>
      </template>
      <el-row v-if="expressInfo.nu" :gutter="10" type="flex" align="middle" class="app-container flex-wrap line-height">
        <el-col :xs="24" :sm="8">运单号: {{ expressInfo.nu }}</el-col>
        <el-col :xs="24" :sm="8">快递公司: {{ formatValue('company_info', expressInfo.com) }}</el-col>
        <el-col :xs="24" :sm="8">
          快递状态: <el-tag :type="expressInfo.state | formStateType">{{ expressState }}</el-tag>
        </el-col>
        <el-col :xs="24" :sm="8">预计到达时间: {{ expressInfo.arrivalTime }}</el-col>
        <el-col :xs="24" :sm="8">平均耗时: {{ expressInfo.totalTime }}</el-col>
        <el-col :xs="24" :sm="8">到达还需要多少时间: {{ expressInfo.remainTime }}</el-col>
      </el-row>
      <div v-else>
        暂无信息
      </div>
      <div
        ref="mapTrack"
        v-loading="mapLoading"
        element-loading-text="地图加载中"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(240, 246, 254, 0.8)"
        :style="{ height: iframeHeight }"
        class="map-track"
      >
        <iframe
          v-if="expressInfo.trailUrl"
          :src="expressInfo.trailUrl"
          frameborder="0"
          width="100%"
          height="100%"
          @load="mapLoading = false"
        />
      </div>
    </el-card>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import express from '@/utils/express'

export default {
  name: 'ExpressDetail',
  filters: {
    formStateType(state) {
      return express.state[state] || state
    }
  },
  data() {
    return {
      mapLoading: true,
      iframeHeight: '100%',
      expressState: '',
      expressInfo: {
        // nu: '', // 运单号
        // com: '', // 快递公司编号
        // state: '', // 快递状态
        // trailUrl: '', // 地图轨迹URL
        // arrivalTime: '', // 预计到达时间
        // totalTime: '', // 平均耗时
        // remainTime: '' // 到达还需要多少时间
        'nu': 'JD0042307996792',
        'com': 'jd',
        'state': '3',
        'trailUrl': 'https://api.kuaidi100.com/tools/map/906838d7e6916f54b365bea207634781_113.612850,34.748257_12',
        'arrivalTime': '2021-05-09 11',
        'totalTime': '0天16小时',
        'remainTime': null
      }
    }
  },
  computed: {
    ...mapGetters(['allOptions'])
  },
  mounted() {
    this.initContent()
  },
  activated() {
    this.initContent()
  },
  methods: {
    initContent() {
      // this.expressInfo = sessionStorage.getItem('mapTrack') ? JSON.parse(sessionStorage.getItem('mapTrack')) : {}
      this.expressState = this.expressState = this.formatValue('express_state', this.expressInfo.state)
      this.$nextTick(() => {
        const domRect = this.$refs.mapTrack.getClientRects()
        this.iframeHeight = `${window.innerHeight - domRect[0].top - 20}px`
      })
      console.log()
    },
    formatValue(key, value) {
      return this.allOptions[key].reduce((t, v) => v.value === value ? v.label : t, value)
    },
    goBack() {
      this.$store.dispatch('tagsView/delView', this.$route).then(() => {
        window.history.go(-1)
      })
    }
  }
}

</script>
<style lang="scss" scoped>
.express-detail {
  .map-track {
    width: 100%;
  }
}
</style>
