<template>
  <div class="app-container">
    <el-card :body-style="{ paddingBottom: '2px' }" class="radius-8 mb-10">
      <el-form ref="form" :model="searchModel" inline>
        <el-form-item prop="com" label="快递公司">
          <el-select
            v-model="searchModel.com"
            placeholder="请选择快递公司"
            filterable
          >
            <el-option v-for="(option, i) in allOptions.company_info" :key="i" v-bind="option" />
          </el-select>
        </el-form-item>
        <el-form-item prop="num">
          <el-input v-model="searchModel.num" placeholder="运单号" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" icon="el-icon-search" @click="handleSearch">查询</el-button>
          <el-button type="default" icon="el-icon-" @click="handleReset('form')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>
    <el-card v-show="!!expressInfo.nu" class="radius-8">
      <template #header>
        <el-row :gutter="20" type="flex" align="middle" class="flex-wrap">
          <el-col :xs="24" :sm="16" :md="20" class="line-height">
            <div>运单号：{{ expressInfo.nu }}</div>
            <div>
              快递公司：{{ formatValue('company_info', expressInfo.com) }}
              <el-tag :type="expressInfo.state | formStateType">{{ expressState }}</el-tag>
            </div>
          </el-col>
          <el-col :xs="24" :sm="8" :md="4" class="text-right">
            <el-button icon="el-icon-position" @click="showMapDialog = true">物流轨迹</el-button>
          </el-col>
        </el-row>
      </template>
      <el-timeline v-if="Array.isArray(expressInfo.data)">
        <el-timeline-item
          v-for="(item, index) of expressInfo.data"
          :key="index"
          :timestamp="item.time"
          :type="item | formatStatusType(expressState)"
          size="large"
          placement="top"
        >
          <el-card :body-style="{ padding: '0 20px' }" class="radius-4">
            <h4>{{ item.status }}</h4>
            <p>{{ item.context }}</p>
          </el-card>
        </el-timeline-item>
      </el-timeline>
    </el-card>
    <el-dialog width="500px" title="物流轨迹" :visible.sync="showMapDialog">
      <el-form :model="mapModel" :rules="mapRules" label-width="90px" label-suffix="：">
        <el-form-item prop="com" label="快递公司">
          {{ formatValue('company_info', mapModel.com) }}
        </el-form-item>
        <el-form-item prop="num" label="运单号">
          {{ mapModel.num }}
        </el-form-item>
        <el-form-item prop="from" label="出发地">
          <el-input v-model="mapModel.from" type="textarea" />
        </el-form-item>
        <el-form-item prop="to" label="目的地">
          <el-input v-model="mapModel.to" type="textarea" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showMapDialog = false">取 消</el-button>
        <el-button type="primary" @click="handleMapTrack">确 定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import express from '@/utils/express'
import { getExpressInfo, getMapTrack } from '@/api/express-info'

export default {
  name: 'ExpressQuery',
  components: {},
  filters: {
    formStateType(state) {
      return express.state[state] || state
    },
    formatStatusType(item, status) {
      return item.status === status ? 'success' : 'info'
    }
  },
  data() {
    return {
      selectLoading: false,
      selectOptions: [],
      searchModel: {
        // com: '',
        // num: ''
        // com: 'jd', // jd
        // num: 'JD0042307996792' // JD0042307996792
      },
      expressState: '',
      expressInfo: {},
      showMapDialog: false,
      mapModel: {
        com: '',
        num: '',
        from: '',
        to: ''
        // from: '河南郑州市',
        // to: '河南郑州市中原区冬青街与雪松路交叉口西南90米秦庄嘉园'
      },
      mapRules: {
        from: [
          { required: true, message: '请填写出发地' }
        ],
        to: [
          { required: true, message: '请填写目的地' }
        ]
      }
    }
  },
  computed: {
    ...mapGetters(['allOptions'])
  },
  watch: {},
  methods: {
    handleSearch() {
      getExpressInfo(this.searchModel).then(result => {
        this.expressInfo = result.response_data
        this.expressState = this.formatValue('express_state', this.expressInfo.state)
        this.mapModel.com = this.expressInfo.com
        this.mapModel.num = this.expressInfo.nu
        this.mapModel.from = this.expressInfo.from
        this.mapModel.to = this.expressInfo.to
      })
    },
    handleMapTrack() {
      getMapTrack(this.mapModel).then(result => {
        sessionStorage.setItem('mapTrack', JSON.stringify(result.response_data))
        this.$router.push({ name: 'express-detail' })
      })
    },
    handleReset(formName) {
      this.$refs[formName].resetFields()
    },
    formatValue(key, value) {
      return this.allOptions[key].reduce((t, v) => v.value === value ? v.label : t, value)
    }
  }
}

</script>
<style lang="scss" scoped>
.wrapper { display: block; }
</style>
