<template>
  <div class="login-container">
    <el-form ref="passwordForm" :model="passwordForm" :rules="passwordRules" class="login-form" autocomplete="on" label-position="left">

      <div class="title-container">
        <h3 class="title">修改密码</h3>
      </div>

      <el-form-item prop="username">
        <span class="svg-container">
          <svg-icon icon-class="user" />
        </span>
        <el-input
          ref="username"
          v-model="passwordForm.username"
          placeholder="用户名"
          name="username"
          type="text"
          tabindex="1"
          autocomplete="on"
        />
      </el-form-item>

      <el-tooltip v-model="capsTooltip.password" content="大写锁定已开启" placement="right" manual>
        <el-form-item prop="password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            :key="passwordType.password"
            ref="password"
            v-model="passwordForm.password"
            :type="passwordType.password"
            placeholder="原密码"
            name="password"
            tabindex="2"
            autocomplete="on"
            @keyup.native="(e) => checkCapslock(e, 'password')"
            @blur="capsTooltip.password = false"
          />
          <span class="show-pwd" @click="showPwd('password')">
            <svg-icon :icon-class="passwordType.password === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>

      <el-tooltip v-model="capsTooltip.new_password" content="大写锁定已开启" placement="right" manual>
        <el-form-item prop="new_password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            :key="passwordType.new_password"
            ref="new_password"
            v-model="passwordForm.new_password"
            :type="passwordType.new_password"
            placeholder="新密码"
            name="password"
            tabindex="3"
            autocomplete="on"
            @keyup.native="(e) => checkCapslock(e, 'new_password')"
            @blur="capsTooltip.new_password = false"
          />
          <span class="show-pwd" @click="showPwd('new_password')">
            <svg-icon :icon-class="passwordType.new_password === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>

      <el-tooltip v-model="capsTooltip.check_password" content="大写锁定已开启" placement="right" manual>
        <el-form-item prop="check_password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            :key="passwordType.check_password"
            ref="check_password"
            v-model="passwordForm.check_password"
            :type="passwordType.check_password"
            placeholder="确认密码"
            name="password"
            tabindex="4"
            autocomplete="on"
            @keyup.native="(e) => checkCapslock(e, 'password')"
            @blur="capsTooltip.check_password = false"
          />
          <span class="show-pwd" @click="showPwd('check_password')">
            <svg-icon :icon-class="passwordType.check_password === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>

      <div class="login-button">
        <el-button :loading="loading" type="primary" @click.native.prevent="handlePassword">
          修改密码
        </el-button>
        <router-link :to="{ path: '/login' }">去登录</router-link> |
        <router-link :to="{ path: '/register' }">去注册</router-link>
      </div>

    </el-form>
  </div>
</template>

<script>
import settings from '@/settings'
import { validatePassword } from '@/utils/validate'

export default {
  name: 'Login',
  components: {},
  data() {
    const validatePassword2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.passwordForm.new_password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      settings,
      passwordForm: {
        username: '',
        password: '',
        new_password: '',
        check_password: ''
      },
      passwordRules: {
        username: [{ required: true, trigger: 'blur', message: '请输入用户名' }],
        password: [{ required: true, trigger: 'blur', validator: validatePassword }],
        new_password: [{ required: true, trigger: 'blur', validator: validatePassword }],
        check_password: [{ required: true, trigger: 'blur', validator: validatePassword2 }]
      },
      passwordType: {
        password: 'password',
        new_password: 'password',
        check_password: 'password'
      },
      loading: false,
      capsTooltip: {
        password: false,
        new_password: false,
        check_password: false
      }
    }
  },
  mounted() {
    if (this.passwordForm.username === '') {
      this.$refs.username.focus()
    } else if (this.passwordForm.password === '') {
      this.$refs.password.focus()
    }
  },
  methods: {
    checkCapslock(e, prop) {
      const { key } = e
      this.capsTooltip[prop] = key && key.length === 1 && (key >= 'A' && key <= 'Z')
    },
    showPwd(prop) {
      if (this.passwordType[prop] === 'password') {
        this.passwordType[prop] = ''
      } else {
        this.passwordType[prop] = 'password'
      }
      this.$nextTick(() => {
        this.$refs[prop].focus()
      })
    },
    handlePassword() {
      this.$refs.passwordForm.validate(valid => {
        if (valid) {
          this.loading = true
          const { username, new_password } = this.passwordForm
          this.$store.dispatch('user/updatePassword', { ...this.passwordForm, check_password: undefined })
            .then(() => {
              this.loading = false
              this.$confirm(`你好 ${username} ！`, '密码修改成功', {
                confirmButtonText: '直接登录'
              }).then(() => {
                this.loading = true
                this.$store.dispatch('user/login', { username, password: new_password }).then(() => {
                  this.$router.push({ path: '/' })
                  this.loading = false
                })
              }).catch(() => {
                this.loading = false
              })
            })
            .catch(() => {
              this.loading = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss">
@import '~@/styles/login.fixed.scss';
</style>

<style lang="scss" scoped>
@import '~@/styles/login.scss';
</style>
