<template>
  <div class="login-container register">
    <el-form ref="registerForm" :model="registerForm" :rules="registerRules" class="login-form" autocomplete="on" label-position="left">

      <div class="title-container">
        <h3 class="title">{{ settings.title }}</h3>
      </div>

      <el-form-item prop="username">
        <span class="svg-container">
          <svg-icon icon-class="user" />
        </span>
        <el-input
          ref="username"
          v-model="registerForm.username"
          placeholder="用户名"
          name="username"
          type="text"
          tabindex="1"
          autocomplete="on"
        />
      </el-form-item>

      <el-tooltip v-model="capsTooltip.password" content="大写锁定已开启" placement="right" manual>
        <el-form-item prop="password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            ref="password"
            :key="passwordType"
            v-model="registerForm.password"
            :type="passwordType"
            placeholder="密码"
            name="password"
            tabindex="2"
            autocomplete="on"
            @keyup.native="(e) => checkCapslock(e, 'password')"
          />
          <span class="show-pwd" @click="showPwd">
            <svg-icon :icon-class="passwordType === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>

      <el-tooltip v-model="capsTooltip.check_password" content="大写锁定已开启" placement="right" manual>
        <el-form-item prop="check_password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            ref="check_password"
            :key="passwordType"
            v-model="registerForm.check_password"
            :type="passwordType"
            placeholder="确认密码"
            name="password"
            tabindex="2"
            autocomplete="on"
            @keyup.native="(e) => checkCapslock(e, 'check_password')"
          />
          <span class="show-pwd" @click="showPwd">
            <svg-icon :icon-class="passwordType === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>

      <el-form-item prop="name">
        <span class="svg-container">
          <svg-icon icon-class="user" />
        </span>
        <el-input
          v-model="registerForm.name"
          placeholder="真实姓名"
          name="username"
          type="text"
          tabindex="3"
          autocomplete="on"
        />
      </el-form-item>

      <el-form-item prop="phone">
        <span class="svg-container">
          <svg-icon icon-class="phone" />
        </span>
        <el-input
          v-model="registerForm.phone"
          placeholder="手机号"
          name="phone"
          type="text"
          tabindex="4"
          maxlength="11"
          autocomplete="on"
        />
      </el-form-item>

      <el-form-item prop="id_card">
        <span class="svg-container">
          <svg-icon icon-class="id_card" />
        </span>
        <el-input
          v-model="registerForm.id_card"
          type="text"
          placeholder="身份证号"
          name="id_card"
          tabindex="5"
          autocomplete="on"
        />
      </el-form-item>

      <el-form-item prop="email">
        <span class="svg-container">
          <svg-icon icon-class="email" />
        </span>
        <el-input
          v-model="registerForm.email"
          type="text"
          placeholder="邮箱"
          name="email"
          tabindex="6"
          autocomplete="on"
          @keyup.native="(e) => checkCapslock(e, 'email')"
        />
      </el-form-item>

      <el-form-item prop="addr">
        <span class="svg-container">
          <svg-icon icon-class="addr" />
        </span>
        <el-input
          v-model="registerForm.addr"
          placeholder="收货地址"
          name="addr"
          type="text"
          tabindex="7"
          autocomplete="on"
          @keyup.enter.native="handleRegister"
        />
      </el-form-item>

      <div class="login-button">
        <el-button :loading="loading" type="primary" @click.native.prevent="handleRegister">
          注 册
        </el-button>
        <router-link :to="{ path: '/login' }">去登录</router-link> |
        <router-link :to="{ path: '/password' }">修改密码</router-link>
      </div>

    </el-form>
  </div>
</template>

<script>
import settings from '@/settings'
import { validatePassword, validateEmail } from '@/utils/validate'

export default {
  name: 'Register',
  data() {
    const validatePassword2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.registerForm.password) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      settings,
      registerForm: {
        username: '',
        check_password: '',
        password: '',
        name: '',
        phone: '',
        id_card: '',
        email: '',
        addr: ''
      },
      registerRules: {
        username: [{ required: true, trigger: 'blur', message: '请输入用户名' }],
        password: [{ required: true, trigger: 'blur', validator: validatePassword }],
        check_password: [{ required: true, trigger: 'blur', validator: validatePassword2 }],
        name: [{ required: true, trigger: 'blur', message: '请输入姓名' }],
        phone: [
          { required: true, trigger: 'blur', message: '请输入手机号' },
          { pattern: /^[1][3-9][0-9]{9}$/, message: '请输入11位手机号' }
        ],
        id_card: [
          { required: true, trigger: 'blur', message: '请输入身份证号' },
          { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, message: '请输入合法的身份证号' }
        ],
        email: [{ required: true, trigger: 'blur', validator: validateEmail }],
        addr: [{ required: true, trigger: 'blur', message: '请输入收货地址' }]
      },
      passwordType: 'password',
      capsTooltip: {
        password: false,
        check_password: false
      },
      loading: false
    }
  },
  watch: {
    action: {
      handler() {
        this.$nextTick(() => {
          this.$refs.registerForm.resetFields()
          if (this.registerForm.username === '') {
            this.$refs.username.focus()
          } else if (this.registerForm.password === '') {
            this.$refs.password.focus()
          }
        })
      },
      immediate: true
    }
  },
  methods: {
    checkCapslock(e, prop) {
      const { key } = e
      this.capsTooltip[prop] = key && key.length === 1 && (key >= 'A' && key <= 'Z')
    },
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    },
    handleRegister() {
      this.$refs.registerForm.validate(valid => {
        if (valid) {
          this.loading = true
          const { username, password } = this.registerForm
          this.$store.dispatch('user/register', { ...this.registerForm, check_password: undefined })
            .then(() => {
              this.loading = false
              this.$confirm(`你好 ${username} ！`, '注册成功', {
                confirmButtonText: '直接登录'
              }).then(() => {
                this.loading = true
                this.$store.dispatch('user/login', { username, password }).then(() => {
                  this.$router.push({ path: '/' })
                  this.loading = false
                })
              }).catch(() => {
                this.loading = false
              })
            })
            .catch(() => {
              this.loading = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}

</script>
<style lang="scss">
@import '~@/styles/login.fixed.scss';
</style>

<style lang="scss" scoped>
@import '~@/styles/login.scss';
.register {
  .login-form {
    padding: 80px 35px 0;
  }
}
</style>
