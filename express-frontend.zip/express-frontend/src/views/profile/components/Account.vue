<template>
  <el-form ref="updateForm" :model="updateForm" :rules="updateRules">
    <el-form-item prop="name" label="真实姓名">
      <el-input
        v-model="updateForm.name"
        placeholder="真实姓名"
        name="username"
        type="text"
        tabindex="2"
        autocomplete="on"
      >
        <span slot="prefix" class="pl-5">
          <svg-icon icon-class="user" />
        </span>
      </el-input>
    </el-form-item>

    <el-form-item prop="phone" label="手机号">
      <el-input
        v-model="updateForm.phone"
        placeholder="手机号"
        name="phone"
        type="text"
        tabindex="3"
        maxlength="11"
        autocomplete="on"
      >
        <span slot="prefix" class="pl-5">
          <svg-icon icon-class="phone" />
        </span>
      </el-input>
    </el-form-item>

    <el-form-item prop="id_card" label="身份证号">
      <el-input
        v-model="updateForm.id_card"
        type="text"
        placeholder="身份证号"
        name="id_card"
        tabindex="4"
        autocomplete="on"
      >
        <span slot="prefix" class="pl-5">
          <svg-icon icon-class="id_card" />
        </span>
      </el-input>
    </el-form-item>

    <el-form-item prop="email" label="邮箱">
      <el-input
        v-model="updateForm.email"
        type="text"
        placeholder="邮箱"
        name="email"
        tabindex="5"
        autocomplete="on"
      >
        <span slot="prefix" class="pl-5">
          <svg-icon icon-class="email" />
        </span>
      </el-input>
    </el-form-item>

    <el-form-item prop="addr" label="收货地址">
      <el-input
        v-model="updateForm.addr"
        placeholder="收货地址"
        name="addr"
        type="text"
        tabindex="6"
        autocomplete="on"
      >
        <span slot="prefix" class="pl-5">
          <svg-icon icon-class="addr" />
        </span>
      </el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="handleUpdate">更 新</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
import { validateEmail } from '@/utils/validate'

export default {
  props: {
    user: {
      type: Object,
      default: () => {
        return {
          username: '',
          avatar: '',
          name: '',
          phone: '',
          id_card: '',
          email: '',
          addr: ''
        }
      }
    }
  },
  data() {
    return {
      updateForm: this.user,
      updateRules: {
        name: [{ required: true, trigger: 'blur', message: '请输入姓名' }],
        phone: [
          { required: true, trigger: 'blur', message: '请输入手机号' },
          { pattern: /^[1][3-9][0-9]{9}$/, message: '请输入11位手机号' }
        ],
        id_card: [
          { required: true, trigger: 'blur', message: '请输入身份证号' },
          { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, message: '请输入合法的身份证号' }
        ],
        email: [{ required: true, trigger: 'blur', validator: validateEmail }],
        addr: [{ required: true, trigger: 'blur', message: '请输入收货地址' }]
      }
    }
  },
  methods: {
    handleUpdate() {
      this.$refs.updateForm.validate(valid => {
        if (!valid) return
        this.$store.dispatch('user/update', this.updateForm).then(() => {
          this.$store.dispatch('user/getInfo').then(() => {
            this.$message.success(`信息修改成功`)
          })
        })
      })
    }
  }
}
</script>
