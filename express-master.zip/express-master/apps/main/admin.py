from django.contrib import admin

from main.models import CompanyInfo
from main.models import ExceptionLog
from main.models import InterfaceRecord
from main.models import SendRecord
from main.models import URLStatus
from main.models import UserInfo


class URLStatusAdmin(admin.ModelAdmin):
    """
    URL状态记录表
    """
    list_display = ("url_path", "start_time", "end_time", "is_active", "msg")
    search_fields = ("url_path",)
    list_filter = ("is_active",)
    list_editable = ("is_active",)


admin.site.register(URLStatus, URLStatusAdmin)


class UserInfoAdmin(admin.ModelAdmin):
    """
    用户信息表
    """
    list_display = ("django_user", "name", "phone", "id_card", "email", "is_active", "create_time", "update_time")
    search_fields = ("name", "phone", "id_card")
    list_filter = ("is_active", "create_time", "update_time")
    list_editable = ("is_active",)


admin.site.register(UserInfo, UserInfoAdmin)


class CompanyInfoAdmin(admin.ModelAdmin):
    """
    快递公司信息表
    """
    list_display = ("company_code", "company_name", "is_active", "create_time", "update_time")
    search_fields = ("company_code", "company_name")
    list_filter = ("is_active", "create_time", "update_time")
    list_editable = ("is_active",)


admin.site.register(CompanyInfo, CompanyInfoAdmin)


class InterfaceRecordAdmin(admin.ModelAdmin):
    """
    接口调用记录表
    """
    list_display = ("id", "url", "req_data", "start_time", "resp_code", "resp_data", "consuming")
    search_fields = ("id", "req_data")
    list_filter = ("url",)


admin.site.register(InterfaceRecord, InterfaceRecordAdmin)


class ExceptionLogAdmin(admin.ModelAdmin):
    """
    程序异常记录表
    """
    list_display = ("id", "function", "reason", "create_time")
    list_filter = ("function", "create_time")


admin.site.register(ExceptionLog, ExceptionLogAdmin)


class SendRecordAdmin(admin.ModelAdmin):
    """
    寄件信息表
    """
    list_display = ("id", "user", "com", "status", "recManName", "recManMobile", "recManPrintAddr", "sendManName",
                    "sendManMobile", "sendManPrintAddr", "cargo", "weight", "weight", "serviceType",
                    "remark", "create_time", "update_time")
    list_filter = ("status", "create_time", "update_time")
    search_fields = ("recManName", "sendManName", "recManMobile", "sendManMobile")


admin.site.register(SendRecord, SendRecordAdmin)
