from django.db import models


class CompanyInfo(models.Model):
    """快递公司信息表"""
    company_code = models.CharField(max_length=100, primary_key=True, verbose_name="快递公司编码")
    company_name = models.CharField(max_length=100, null=True, blank=True, verbose_name="快递公司信息")

    is_active = models.BooleanField(default=False, verbose_name="是否激活")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="删除时间")

    class Meta:
        verbose_name = "快递公司信息表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.company_code
