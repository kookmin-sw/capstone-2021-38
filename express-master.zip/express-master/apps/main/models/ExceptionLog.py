from django.db import models


class ExceptionLog(models.Model):
    """
    程序异常记录表
    """

    function = models.CharField(max_length=100, null=True, blank=True, verbose_name='程序异常的地点')
    reason = models.TextField(null=True, blank=True, verbose_name='异常原因')
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='异常发生时间')

    class Meta:
        verbose_name = '程序异常记录表'
        verbose_name_plural = verbose_name
        ordering = ('-create_time',)
