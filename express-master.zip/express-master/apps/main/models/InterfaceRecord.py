from django.db import models


class InterfaceRecord(models.Model):
    """接口调用记录表"""
    url = models.CharField(max_length=200, null=True, blank=True, verbose_name="请求地址")
    req_data = models.TextField(null=True, blank=True, verbose_name="请求参数")
    start_time = models.DateTimeField(null=True, blank=True, verbose_name="请求开始时间")
    resp_code = models.IntegerField(null=True, blank=True, verbose_name="接口返回状态码")
    resp_data = models.TextField(null=True, blank=True, verbose_name="接口返回数据")

    consuming = models.CharField(max_length=20, null=True, blank=True, verbose_name="请求耗时")

    class Meta:
        verbose_name = "接口调用记录表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.pk)
