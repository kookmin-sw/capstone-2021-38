from django.db import models

from main.models.CompanyInfo import CompanyInfo
from main.models.UserInfo import UserInfo


class SendRecord(models.Model):
    """寄件信息表"""
    STATUS = (
        ("00", "准备下单"),
        ("01", "下单中"),
        ("02", "下单成功"),
        ("03", "下单失败"),
        ("04", "取消")
    )
    user = models.ForeignKey(UserInfo, on_delete=models.CASCADE, null=True, blank=True, verbose_name="所属用户")
    com = models.ForeignKey(CompanyInfo, on_delete=models.CASCADE, null=True, blank=True, verbose_name="所属快递公司")
    recManName = models.CharField(max_length=100, null=True, blank=True, verbose_name="收件人姓名")
    recManMobile = models.CharField(max_length=100, null=True, blank=True, verbose_name="收件人手机号")
    recManPrintAddr = models.CharField(max_length=100, null=True, blank=True, verbose_name="收件人地址")
    sendManName = models.CharField(max_length=100, null=True, blank=True, verbose_name="寄件人姓名")
    sendManMobile = models.CharField(max_length=100, null=True, blank=True, verbose_name="寄件人手机号")
    sendManPrintAddr = models.CharField(max_length=100, null=True, blank=True, verbose_name="寄件人地址")
    cargo = models.CharField(max_length=100, null=True, blank=True, verbose_name="物品名称")
    weight = models.CharField(max_length=100, null=True, blank=True, verbose_name="物品总重量（KG）")
    serviceType = models.CharField(max_length=100, null=True, blank=True, verbose_name="快递业务服务类型")
    remark = models.TextField(max_length=100, null=True, blank=True, verbose_name="备注")

    status = models.CharField(max_length=10, default="00", choices=STATUS, verbose_name="订单状态")

    taskId = models.CharField(max_length=200, null=True, blank=True, unique=True, verbose_name="任务ID")
    orderId = models.CharField(max_length=200, null=True, blank=True, unique=True, verbose_name="订单ID")
    cancelMsg = models.TextField(null=True, blank=True, verbose_name="取消原因")

    courierName = models.CharField(max_length=30, null=True, blank=True, verbose_name="快递员姓名")
    courierMobile = models.CharField(max_length=30, null=True, blank=True, verbose_name="快递员电话")
    expressStatus = models.CharField(max_length=10, null=True, blank=True, verbose_name="快递状态")
    freight = models.CharField(max_length=10, null=True, blank=True, verbose_name="运费")

    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="更新时间")

    class Meta:
        verbose_name = "寄件信息表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return str(self.pk)
