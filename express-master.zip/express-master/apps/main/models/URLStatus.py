from django.db import models


class URLStatus(models.Model):
    """
    URL 状态记录表
    """
    url_path = models.CharField(max_length=50, null=True, blank=True, verbose_name='URL路径')
    start_time = models.DateTimeField(null=True, blank=True, verbose_name="维护开始时间")
    end_time = models.DateTimeField(null=True, blank=True, verbose_name="维护结束时间")
    is_active = models.BooleanField(default=False, verbose_name="是否瘫痪")
    msg = models.TextField(default='该服务正在维护，暂停使用。请各位用户谅解，对您造成的不便，我们深表歉意。', verbose_name='提示信息')

    class Meta:
        verbose_name = "URL状态记录表"
        verbose_name_plural = verbose_name
