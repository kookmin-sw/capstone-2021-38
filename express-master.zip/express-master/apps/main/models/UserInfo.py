from django.contrib.auth.models import User
from django.db import models


class UserInfo(models.Model):
    """用户信息"""
    django_user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="关联的django用户")

    auth_token = models.CharField(max_length=100, null=True, blank=True, verbose_name="token")
    expiration_time = models.DateTimeField(null=True, blank=True, verbose_name='token过期时间')

    name = models.CharField(max_length=20, null=True, blank=True, verbose_name="用户姓名")
    phone = models.CharField(max_length=20, null=True, blank=True, verbose_name='联系方式')
    id_card = models.CharField(max_length=20, null=True, blank=True, verbose_name="身份证号")
    email = models.CharField(max_length=200, null=True, blank=True, verbose_name="邮箱")
    addr = models.TextField(max_length=200, null=True, blank=True, verbose_name="地址")

    is_active = models.BooleanField(default=False, verbose_name="是否激活")
    create_time = models.DateTimeField(auto_now_add=True, verbose_name="创建时间")
    update_time = models.DateTimeField(auto_now=True, verbose_name="删除时间")

    class Meta:
        verbose_name = "用户信息表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.django_user.username
