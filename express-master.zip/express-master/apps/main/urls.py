from django.conf import settings
from django.conf.urls import url
from django.views.static import serve

from main.views.Gateway import *

urlpatterns = [
    url(r'^get_settings/', GetSettings.as_view(), name="获取系统配置"),
    url(r'^gateway/', Gateway.as_view(), name="网关"),
    url(r"^call_back/", CallBack.as_view(), name="快递100回调接口"),
    url(r"^static/(?P<path>.*)$", serve, {'document_root': settings.STATIC_ROOT}, name='static')
]
