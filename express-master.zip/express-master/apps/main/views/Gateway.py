import traceback

from django.views import View

from main.views.common import *
from main.views.dao.CompanyInfoDao import CompanyInfoDao
from main.views.dao.ExceptionLogDao import ExceptionLogDao
from main.views.dao.SendRecordDao import SendRecordDao
from main.views.dao.URLStatusDao import URLStatusDao
from main.views.dao.UserInfoDao import UserInfoDao
from main.views.utils.PublicUtils import *
from .function import FUNCTION


class Gateway(View):
    """网关"""

    def post(self, request):
        # noinspection PyBroadException
        try:
            request_data = deal_request(request)
            method = request_data.get('method')
            content = request_data.get("content", {})
            if method not in FUNCTION.keys():
                return build_error_response(code='1004', msg='{} 方法不存在。'.format(method))

            # 校验服务是否在维护中
            url = URLStatusDao().get({"url_path": request.path}).first()
            if url and url.start_time <= datetime.now() <= url.end_time:
                return build_error_response(code='1002', msg=url.msg)

            # 检查用户是否登录
            auth_token = request.META.get('HTTP_TOKEN')
            if not (method == "express.login.manage" and content.get("state") in
                    ["login", "register", "update", "update_password"]):
                user = UserInfoDao().get({"auth_token": auth_token, "expiration_time__gt": datetime.now()}).first()
                if not user:
                    return build_error_response(code="1005", msg="用户未登录")
                request.user = user

            return FUNCTION[method](request, content).deal_request()
        except Exception:
            print(traceback.format_exc())
            obj = ExceptionLogDao().record_except_log("Gateway", traceback.format_exc())
            return build_error_response(code='1001', msg=f"系统异常，请稍后重试，异常编码：{obj.pk}")


class GetSettings(View):
    """获取系统配置信息"""

    def get(self, request):
        # noinspection PyBroadException
        try:
            response_data = {
                "company_info": [{"label": i.company_name, "value": i.company_code} for i in CompanyInfoDao().get()],
                "express_state": [{"label": v, "value": k} for k, v in EXPRESS_STATE.items()],
                "send_record_status": [{"label": v, "value": k} for k, v in SEND_RECORD_STATUS.items()]
            }
            return build_success_response(response_data=response_data)
        except Exception:
            print(traceback.format_exc())
            obj = ExceptionLogDao().record_except_log("Gateway", traceback.format_exc())
            return build_error_response(code='1001', msg=f"系统异常，请稍后重试，异常编码：{obj.pk}")


class CallBack(View):
    """接收快递100寄件回调"""

    def post(self, request):
        # noinspection PyBroadException
        try:
            req_data = deal_request(request)
            param = json.loads(req_data.get("param"))
            data = param.get("data")
            taskId = req_data.get("taskId")

            send_record = SendRecordDao().select({"taskId": taskId}).first()
            if not send_record:
                result = {"result": False, "returnCode": "500", "message": "订单不存在"}
            else:
                if data.get("status") == 1:
                    send_record.courierName = data.get("courierName")
                    send_record.courierMobile = data.get("courierMobile")
                    send_record.freight = data.get("freight")
                    send_record.status = "02"
                    send_record.save()
                result = {"result": True, "returnCode": "200", "message": ""}
        except Exception:
            result = {"result": True, "returnCode": "500", "message": "服务异常"}
            print(traceback.format_exc())
        return JsonResponse(status=200, data=result)
