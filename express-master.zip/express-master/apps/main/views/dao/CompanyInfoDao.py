from main.models.CompanyInfo import CompanyInfo
from .PublicDao import PublicDao


class CompanyInfoDao(PublicDao):

    def __init__(self):
        super(CompanyInfoDao, self).__init__(CompanyInfo)

    def get(self, keys=None):
        default_keys = {"is_active": True}
        obj_set = self.select(default_keys)
        if keys:
            obj_set = obj_set.filter(**keys)
        return obj_set
