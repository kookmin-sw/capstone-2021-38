import requests
from django.conf import settings

from main.models import ExceptionLog


class ExceptionLogDao:
    """
    程序异常记录表
    """

    def __init__(self):
        self.manager = ExceptionLog.objects

    def record_except_log(self, function, reason):
        """
        记录异常日志
        :return:
        """
        obj = self.manager.create(function=function, reason=reason)

        try:
            if function in ["Gateway"]:
                data = {
                    "msgtype": "text",
                    "text": {"content": f"系统异常：{obj.id}", "mentioned_mobile_list": ["15036505580"]}}
                # requests.post(settings.ROBOT_URL, json=data)
        except Exception as e:
            print("推送企业微信异常：", e)

        return obj
