from main.models.InterfaceRecord import InterfaceRecord
from .PublicDao import PublicDao


class InterfaceRecordDao(PublicDao):

    def __init__(self):
        super(InterfaceRecordDao, self).__init__(InterfaceRecord)
