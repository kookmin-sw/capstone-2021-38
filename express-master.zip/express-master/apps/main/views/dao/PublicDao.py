class PublicDao(object):

    def __init__(self, model):
        self.manager = model.objects

    def select(self, keys=None):
        if not keys:
            return self.manager.all()
        return self.manager.filter(**keys)

    def insert(self, keys):
        return self.manager.create(**keys)

    def get_or_create(self, keys):
        obj, _ = self.manager.get_or_create(**keys)
        return obj

    @staticmethod
    def update(obj, keys):
        for k, v in keys.items():
            setattr(obj, k, v)
        obj.save()

        return obj
