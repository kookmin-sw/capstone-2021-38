from main.models.SendRecord import SendRecord
from .PublicDao import PublicDao


class SendRecordDao(PublicDao):

    def __init__(self):
        super(SendRecordDao, self).__init__(SendRecord)
