from main.models import URLStatus
from main.views.dao.PublicDao import PublicDao
from datetime import datetime


class URLStatusDao(PublicDao):
    """
    URl 状态信息表
    """

    def __init__(self):
        super(URLStatusDao, self).__init__(URLStatus)

    def get(self, keys=None):
        """
        查询
        :return:
        """
        default_keys = {"is_active": True, "start_time__lte": datetime.now(), "end_time__gte": datetime.now()}
        obj_set = self.manager.filter(**default_keys)

        if keys:
            obj_set = obj_set.filter(**keys)
        return obj_set
