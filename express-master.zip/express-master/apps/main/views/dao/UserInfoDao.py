from main.models import UserInfo
from .PublicDao import PublicDao


class UserInfoDao(PublicDao):

    def __init__(self):
        super(UserInfoDao, self).__init__(UserInfo)

    def get(self, keys=None):
        default_keys = {"is_active": True}
        obj_set = self.select(default_keys)
        if keys:
            obj_set = obj_set.filter(**keys)

        return obj_set
