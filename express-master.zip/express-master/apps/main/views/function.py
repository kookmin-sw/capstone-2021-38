from main.views.service.LoginService import LoginService
from main.views.service.ExpressService import ExpressService
from main.views.service.SendService import SendService

FUNCTION = {
    # 用户登录模块
    "express.login.manage": LoginService,
    # 快递信息管理模块
    'express.express_info.manage': ExpressService,
    # 寄件模块
    'express.send.manage': SendService,
}

