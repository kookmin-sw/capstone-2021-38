from main.views.utils.PublicUtils import *


class BaseService(object):

    def __init__(self, request, content):
        self.request = request
        self.content = content
        self.state = content.get("state")
        self.build_success_response = build_success_response
        self.build_error_response = build_error_response
        self.user = request.user
