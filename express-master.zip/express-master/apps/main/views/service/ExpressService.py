from main.views.utils.InterfaceUtil import InterfaceUtil
from .BaseService import BaseService


class ExpressService(BaseService):
    """快递信息管理模块"""

    def __init__(self, request, content):
        super(ExpressService, self).__init__(request, content)

    def deal_request(self):

        interface_util = InterfaceUtil()

        if self.state == "select":
            return self.select(interface_util)
        elif self.state == "maptrack":
            return self.maptrack(interface_util)
        else:
            return self.build_error_response(code="1003", msg=f"{self.state}方法不存在")

    def select(self, interface_util):
        """实时查询快递"""
        com = self.content.get("com")
        num = self.content.get('num')
        phone = self.user.phone
        status_code, response = interface_util.query_do(com, num, phone)
        if status_code != 200:
            return self.build_error_response(code="1003", msg="快递信息查询失败，请稍后再试")
        returnCode = response.get("returnCode")
        if returnCode and returnCode != "200":
            message = response.get("message", "快递信息查询失败。")
            return self.build_error_response(code="1003", msg=message)

        response_data = {
            "state": response.get("state"),
            "com": response.get("com"),
            "nu": response.get("nu"),
            "data": response.get("data")
        }
        return self.build_success_response(response_data=response_data)

    def maptrack(self, interface_util):
        """地图轨迹追踪"""
        com = self.content.get("com")
        num = self.content.get('num')
        from_ = self.content.get('from')
        to = self.content.get('to')
        status_code, response = interface_util.maptrack_do(com, num, from_, to)
        if status_code != 200:
            return self.build_error_response(code="1003", msg="快递地图追踪失败，请稍后再试")
        returnCode = response.get("returnCode")
        if returnCode and returnCode != "200":
            message = response.get("message", "快递地图追踪失败。")
            return self.build_error_response(code="1003", msg=message)
        response_data = {
            "nu": response.get("nu"),
            "com": response.get("com"),
            "state": response.get("state"),
            "trailUrl": response.get("trailUrl"),
            "arrivalTime": response.get("arrivalTime"),
            "totalTime": response.get("totalTime"),
            "remainTime": response.get("remainTime"),
            "data": response.get("data"),
            "routeInfo": response.get("routeInfo"),
        }
        return self.build_success_response(response_data=response_data)
