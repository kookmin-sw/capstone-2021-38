import uuid
from datetime import datetime, timedelta

from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from main.views.dao.UserInfoDao import UserInfoDao
from .BaseService import BaseService


class LoginService(BaseService):
    """用户注册、登录、注销"""

    def __init__(self, request, content):
        super(LoginService, self).__init__(request, content)

    def deal_request(self):

        user_info_dao = UserInfoDao()
        username = self.content.get("username")
        password = self.content.get("password")
        new_password = self.content.get("new_password")
        name = self.content.get("name")
        phone = self.content.get("phone")
        id_card = self.content.get("id_card")
        email = self.content.get("email")

        if self.state == "register":
            return self.register(user_info_dao, username, password, name, phone, id_card, email)
        elif self.state == "login":
            return self.login(user_info_dao, username, password)
        elif self.state == "logout":
            return self.logout()
        elif self.state == "update":
            return self.update(username, password, name, phone, id_card, email)
        else:
            return self.build_error_response(code="1003", msg=f"{self.state}方法不存在")

    def register(self, user_info_dao, username, password, name, phone, id_card, email):
        """注册"""

        if User.objects.filter(username=username):
            return self.build_error_response(code="1003", msg=f"用户名{username}已存在。")

        django_user = User.objects.create(username=username)
        django_user.set_password(password)
        django_user.save()

        user_info_dao.insert({
            "django_user": django_user,
            "name": name,
            "email": email,
            "phone": phone,
            "id_card": id_card,
            "is_active": True,
        })
        return self.build_success_response()

    def login(self, user_info_dao, username, password):

        user = user_info_dao.select({"django_user__username": username}).first()
        if not user:
            return self.build_error_response(code="1003", msg=f"用户{username}不存在")

        if not user.is_active:
            return self.build_error_response(code="1003", msg=f"用户{username}未激活")

        if not authenticate(self.request, username=username, password=password):
            return self.build_error_response(code="1003", msg='用户名或密码有误。')

        user.auth_token = str(uuid.uuid4())
        user.expiration_time = datetime.now() + timedelta(hours=2)
        user.save()

        return self.build_success_response(response_data={"TOKEN": user.auth_token})

    def logout(self):
        user = self.request.user
        user.expiration_time = datetime.now()
        user.save()
        return self.build_success_response()

    def update(self, username, password, name, phone, id_card, email):
        """修改用户信息"""
        django_user = authenticate(self.request, username=username, password=password)
        if not django_user:
            return self.build_error_response(code="1003", msg='用户名或密码有误。')

        user = UserInfoDao().get({"django_user": django_user}).first()
        if not user:
            return self.build_error_response(code="1003", msg="用户未激活。")

        user.name = name
        user.phone = phone
        user.id_card = id_card
        user.email = email
        user.save()

        return self.build_success_response()

    def update_password(self, username, password, new_password):
        """修改密码"""
        django_user = authenticate(self.request, username=username, password=password)
        if not django_user:
            return self.build_error_response(code="1003", msg='用户名或密码有误。')

        django_user.set_password(new_password)
        django_user.save()
        return self.build_success_response()

