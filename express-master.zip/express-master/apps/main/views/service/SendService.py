from main.views.dao.CompanyInfoDao import CompanyInfoDao
from main.views.dao.SendRecordDao import SendRecordDao
from main.views.utils.InterfaceUtil import InterfaceUtil
from .BaseService import BaseService
from main.views.dao.URLStatusDao import URLStatusDao


class SendService(BaseService):
    """寄件模块"""

    def __init__(self, request, content):
        super(SendService, self).__init__(request, content)

    def deal_request(self):

        interface_util = InterfaceUtil()

        if self.state == "querymkt":
            return self.querymkt(interface_util)
        elif self.state == "place_order":
            return self.place_order(interface_util)
        elif self.state == "cancel":
            return self.cancel(interface_util)
        elif self.state == "select":
            return self.select()
        else:
            return self.build_error_response(code="1003", msg=f"{self.state}方法不存在")

    def querymkt(self, interface_util):
        """获取可以寄件的快递公司"""
        sendAddr = self.content.get("sendAddr")
        if not sendAddr:
            sendAddr = self.request.user.addr
        status_code, response = interface_util.querymkt(sendAddr)
        if status_code != 200:
            return self.build_error_response(code="1003", msg="获取快递公司信息失败，请稍后再试")
        returnCode = response.get("returnCode")
        if returnCode and returnCode != "200":
            message = response.get("message", "获取快递公司信息失败。")
            return self.build_error_response(code="1003", msg=message)
        data = response.get("data", {})
        mktInfo = data.get("mktInfo")
        new_mktInfo = []
        for i in mktInfo:
            new_mktInfo.append({
                "serviceType": i.get("serviceType"),
                "com": i.get("kuaidiCom")
            })
        data["mktInfo"] = new_mktInfo

        return self.build_success_response(response_data=data)

    def place_order(self, interface_util):
        """下单接口"""
        url_status = URLStatusDao().get({"url_path": "cancel_place_order"}).first()
        if url_status:
            return self.build_error_response(code="1003", msg=url_status.msg)

        kuaidicom = self.content.get("com")
        company_info = CompanyInfoDao().get({"company_code": kuaidicom}).first()
        if not company_info:
            return self.build_error_response(code="1003", msg="该快递公司暂不可寄件，请重新选择快递公司。")

        user = self.request.user
        sendManName = self.content.get("sendManName")
        sendManMobile = self.content.get("sendManMobile")
        sendManPrintAddr = self.content.get("sendManPrintAddr")
        if not sendManName:
            sendManName = user.name
        if not sendManMobile:
            sendManMobile = user.phone
        if not sendManPrintAddr:
            sendManPrintAddr = user.addr

        pk = self.content.get("id")
        send_record = SendRecordDao().select({"pk": pk}).first()
        if pk and send_record:
            param = {
                "serviceType": send_record.serviceType,  # 快递业务服务类型
                "kuaidicom": send_record.com,  # 快递公司的编码
                "recManName": send_record.recManName,  # 收件人姓名
                "recManMobile": send_record.recManMobile,  # 收件人的手机号
                "recManPrintAddr": send_record.recManPrintAddr,  # 收件人所在完整地址
                "sendManName": send_record.sendManName,  # 寄件人姓名
                "sendManMobile": send_record.sendManMobile,  # 寄件人的手机号
                "sendManPrintAddr": send_record.sendManPrintAddr,  # 寄件人所在的完整地址
                "cargo": send_record.cargo,  # 物品名称
                "weight": send_record.weight,  # 物品重量
                "remark": send_record.remark,  # 备注
            }

        else:
            param = {
                "serviceType": self.content.get("serviceType"),  # 快递业务服务类型
                "kuaidicom": kuaidicom,  # 快递公司的编码
                "recManName": self.content.get("recManName"),  # 收件人姓名
                "recManMobile": self.content.get("recManMobile"),  # 收件人的手机号
                "recManPrintAddr": self.content.get("recManPrintAddr"),  # 收件人所在完整地址
                "sendManName": sendManName,  # 寄件人姓名
                "sendManMobile": sendManMobile,  # 寄件人的手机号
                "sendManPrintAddr": sendManPrintAddr,  # 寄件人所在的完整地址
                "cargo": self.content.get("cargo", ""),  # 物品名称
                "weight": self.content.get("weight", ""),  # 物品重量
                "remark": self.content.get("remark", ""),  # 备注
            }
            keys = param.copy()
            keys.pop("kuaidicom")
            send_record = SendRecordDao().insert(keys)
            send_record.user = user
            send_record.com = company_info
            send_record.save()

        status_code, response = interface_util.place_order(param)
        if status_code != 200:
            send_record.status = "03"
            return self.build_error_response(code="1003", msg="下单失败，请稍后再试")
        returnCode = response.get("returnCode")
        if returnCode and returnCode != "200":
            send_record.status = "03"
            message = response.get("message", "下单失败。")
            return self.build_error_response(code="1003", msg=message)

        data = response.get("data", {})
        send_record.status = "01"
        send_record.taskId = data.get("taskId")
        send_record.orderId = data.get("orderId")
        send_record.save()

        return self.build_success_response()

    def cancel(self, interface_util):
        """取消已经下的单子"""
        pk = self.content.get("id")
        cancelMsg = self.content.get("cancelMsg")
        send_record = SendRecordDao().select({"id": pk, "status__in": ["01", "02"]}).first()
        if not send_record:
            return self.build_error_response(code="1003", msg="该订单不存在或不可进行取消")

        param = {
            "taskId": send_record.taskId,
            "orderId": send_record.orderId,
            "cancelMsg": cancelMsg,
        }
        status_code, response = interface_util.cancel(param)
        if status_code != 200:
            return self.build_error_response(code="1003", msg="取消订单失败，请稍后再试")
        returnCode = response.get("returnCode")
        if returnCode and returnCode != "200":
            message = response.get("message", "取消订单失败。")
            return self.build_error_response(code="1003", msg=message)

        send_record.status = "04"
        send_record.cancelMsg = cancelMsg
        send_record.save()

        return self.build_success_response()

    def select(self):
        query_key = {"user": self.request.user}
        for k, v in self.content.copy().items():
            if v is None or k == "state" or v == "":
                continue
            elif k in ["create_time", "update_time"]:
                query_key[f"{k}__range"] = v
            elif k == "com":
                query_key["com__company_code"] = v
            elif k in ["recManName", "recManMobile", "recManPrintAddr", "sendManName", "sendManMobile",
                       "sendManPrintAddr", "cargo", "serviceType", "remark"]:
                query_key[f"{k}__icontains"] = v
            else:
                query_key[k] = v
        send_record_set = SendRecordDao().select(query_key)
        response_data = [{
            "id": i.id,
            "user": i.user.django_user.username,
            "com": i.com.company_code,
            "recManName": i.recManName,
            "recManMobile": i.recManMobile,
            "recManPrintAddr": i.recManPrintAddr,
            "sendManName": i.sendManName,
            "sendManMobile": i.sendManMobile,
            "sendManPrintAddr": i.sendManPrintAddr,
            "cargo": i.cargo,
            "weight": i.weight,
            "serviceType": i.serviceType,
            "remark": i.remark,
            "status": i.status,
            "cancelMsg": i.cancelMsg,
            "orderId": i.orderId,
            "create_time": i.create_time.strftime("%Y-%m-%d %H:%M:%S"),
            "update_time": i.update_time.strftime("%Y-%m-%d %H:%M:%S"),

        } for i in send_record_set]

        return self.build_success_response(response_data=response_data)
