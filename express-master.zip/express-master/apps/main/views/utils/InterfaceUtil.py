import hashlib
import json
import time
from datetime import datetime

import requests
from django.conf import settings

from main.views.dao.InterfaceRecordDao import InterfaceRecordDao


class InterfaceUtil(object):
    """用于请求快递100的接口"""

    def __init__(self):
        self.key = settings.KEY
        self.query_base_url = settings.QUERY_BASE_URL
        self.send_base_url = settings.SEND_BASE_URL
        self.send_back_url = settings.SEND_BACK_URL
        self.customer = settings.CUSTOMER
        self.secret = settings.SECRET
        self.interface_record_dao = InterfaceRecordDao()

    def sign(self, sign_str):
        """签名"""
        md = hashlib.md5()
        md.update(sign_str.encode(encoding='utf-8'))
        return md.hexdigest().upper()

    def do_request(self, param, method, api_method=None):
        """发送请求"""
        param_json = json.dumps(param)

        # 构建请求参数
        if method in ['borderbestapi.do']:
            url = f"{self.send_base_url}{method}"
            t = str(int(time.time())) + "000"
            sign_str = f"{param_json}{t}{self.key}{self.secret}"
            req_data = {
                "method": api_method,
                "key": self.key,
                "param": param_json,
                "sign": self.sign(sign_str),
                "t": t,
            }
        else:
            url = f"{self.query_base_url}{method}"
            sign_str = f"{param_json}{self.key}{self.customer}"
            req_data = {
                "customer": self.customer,
                "param": param_json,
                "sign": self.sign(sign_str),
            }

        # 记录调用信息
        print(req_data)
        print(url)
        interface_record = self.interface_record_dao.insert({
            "url": url,
            "req_data": req_data,
            "start_time": datetime.now()
        })
        start_time = time.time()
        try:
            response = requests.post(url, req_data, timeout=5)
        except Exception as e:
            status_code = 0
            response_data = e
        else:
            if response.status_code != 200:
                status_code = response.status_code
                response_data = response.text
            else:
                status_code = response.status_code
                response_data = response.json()
        print(status_code, response_data)
        self.interface_record_dao.update(interface_record, {
            "resp_code": status_code,
            "resp_data": response_data,
            "consuming": str(time.time() - start_time),
        })
        return status_code, response_data

    def query_do(self, com, num, phone):
        """
        实时查询快递信息
        :param com: 物流公司编码
        :param num: 订单编号/快递编号
        :param phone: 手机号
        :return:
        """
        param = {
            "com": com,
            "num": num,
            "phone": phone,
            "from": "",
            "to": "",
            "resultv2": "1",
            "show": "0",
            "order": "desc",
        }
        return self.do_request(param, "query.do")

    def maptrack_do(self, com, num, from_, to):
        """
        地图轨迹追踪
        :param com: 快递公司编码
        :param num: 快递单号
        :param from_: 出发地
        :param to: 目的地
        :return:
        """
        param = {
            "com": com,
            "num": num,
            "from": from_,
            "to": to,
            "show": "0",
            "order": "desc",
            "orderTime": "",
        }
        return self.do_request(param, "maptrack.do")

    def querymkt(self, sendAddr):
        """
        查询可以寄件的快递公司
        :param sendAddr: 寄件人所在的完整地址，如广东深圳市深圳市南山区科技南十二路2号金蝶软件园B10
        :return:
        """
        param = {
            "sendAddr": sendAddr,
        }
        return self.do_request(param, "borderbestapi.do", "querymkt")

    def place_order(self, param):
        """
        下单接口
        """
        param["callBackUrl"] = self.send_back_url

        return self.do_request(param, "borderbestapi.do", "bOrderBest")

    def cancel(self, param):
        """取消接口"""
        return self.do_request(param, "borderbestapi.do", "cancelBest")
