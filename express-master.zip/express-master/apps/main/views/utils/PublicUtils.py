import json
from datetime import datetime

from django.http import JsonResponse


def deal_request(request, content=False):
    """
    功能：处理请求对象
    :return:
    """
    request_data = dict()
    try:
        request_data.update(json.loads(request.body))
    except:
        pass
    request_data.update(request.GET.dict())
    request_data.update(request.POST.dict())
    if content and request_data.get('content'):
        request_data = request_data.get('content')
    return request_data


def build_error_response(code, msg):
    """
    构建失败的返回数据
    :param code:
    :param msg:
    :return:
    """
    response = {'data_type': '2', 'code': code, 'msg': msg, 'response_data': '',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    return JsonResponse(status=200, data=response, json_dumps_params={"ensure_ascii": False})


def build_success_response(response_data='', msg='', **kwargs):
    """
    构建请求成功的返回数据
    :return:
    """
    response = {'data_type': '1', 'code': '1000', 'msg': msg, 'response_data': response_data,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    response.update(**kwargs)
    return JsonResponse(status=200, data=response, json_dumps_params={"ensure_ascii": False})
