# 调试模式开关
DEBUG = True

# 异常监控机器人
ROBOT_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=c2470573-6190-485b-acd3-650380e40a0b"

# 快递100接口配置
KEY = "xrvGnHuZ5671"
QUERY_BASE_URL = "https://poll.kuaidi100.com/poll/"
SEND_BASE_URL = "https://order.kuaidi100.com/order/"
SEND_BACK_URL = "https://jinjiakang.natapp4.cc/express/call_back/"
CUSTOMER = "525FB2BA41156E0109784BFD44702621"
SECRET = "5a7fdd4c56704738abbf3e9aa371a018"
